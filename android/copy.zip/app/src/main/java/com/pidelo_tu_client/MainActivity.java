package com.pidelo_tu_client;

import com.facebook.react.ReactActivity;
import android.widget.LinearLayout;
import android.graphics.Color;
import android.widget.TextView;
import android.widget.ImageView;
import android.view.Gravity;
import android.util.TypedValue;
import com.reactnativenavigation.controllers.SplashActivity;


public class MainActivity extends SplashActivity {
	@Override
    public LinearLayout createSplashLayout() {
        LinearLayout view = new LinearLayout(this);
        ImageView image = new ImageView(this);

        view.setBackgroundResource(R.drawable.bg);
        view.setGravity(Gravity.CENTER);

        //textView.setTextColor(Color.parseColor("#FFFFFF"));
        //textView.setText("React Native Navigation");
        //textView.setGravity(Gravity.CENTER);
        //textView.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 40);
        image.setImageResource(R.drawable.icon);

        view.addView(image);
        return view;
    }
}
